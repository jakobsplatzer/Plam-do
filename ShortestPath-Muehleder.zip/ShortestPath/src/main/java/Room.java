import java.util.LinkedList;

public class Room {
    private char[][] layout;

    public Room(char[][] layout) {
        this.layout = layout;
    }

    public boolean isAccessible(Position position) {
        int x = position.getX();
        int y = position.getY();

        if (x < 0 || x >= layout.length) {
            return false;
        }
        if (y < 0 || y >= layout[0].length) {
            return false;
        }
        if (layout[x][y] == '#') {
            return false;
        }
        return true;
    }

    public void print() {
        for (int x = 0; x < layout.length; x++) {
            for (int y = 0; y < layout[x].length; y++) {
                System.out.print(layout[x][y]);
            }
            System.out.println();
        }
    }

    public int[][] getDistanceMatrix(Position target) {
        int[][] distance = new int[layout.length][layout[0].length];

        for (int x = 0; x < distance.length; x++) {
            for (int y = 0; y < distance[x].length; y++) {
                distance[x][y] = -1;                                // alles -1 setzen
            }
        }
        distance[target.getX()][target.getY()] = 0; // ziel auf 0 setzen

        LinkedList<Position> list = new LinkedList<>();             // Queue
        list.add(target);

        while (list.isEmpty() == false) {
            Position current = list.remove();               // gespeichert in curr und weggenommen
            Position[] neighbors = current.getNeighbors(); // nachbarn holen

            for (int i = 0; i < neighbors.length; i++) {
                Position neighbor = neighbors[i];
                if (isAccessible(neighbor)) {
                    int x = neighbor.getX();
                    int y = neighbor.getY();

                    if (distance[x][y] == -1) {
                        distance[x][y] = distance[current.getX()][current.getY()] + 1;
                        list.add(neighbor);
                    }
                }
            }
        }
        return distance;
    }

    public void printDistanceMatrix(Position target) {
        int[][] distance = getDistanceMatrix(target);
        for (int x = 0; x < distance.length; x++) {
            for (int y = 0; y < distance[x].length; y++) {
                if (layout[x][y] == '#') {
                    System.out.print("## ");
                } else {
                    System.out.printf("%2d ", distance[x][y]);
                }
            }
            System.out.println();
        }
    }




    // -----------------------------------------------------------------------

    public void printShortestPath(Position start, Position target) {
        int[][] distance = getDistanceMatrix(target);
        Position current = start;
        System.out.print("(" + current.getX() + "|" + current.getY() + ")");

        while (current.getX() != target.getX() || current.getY() != target.getY()) {
            Position next = null;
            Position[] neighbors = current.getNeighbors(); // nachbar holen

            for (int i = 0; i < neighbors.length; i++) { // durch nachbarn
                Position neighbor = neighbors[i];
                if (isAccessible(neighbor)) {           // betretbar
                    int x = neighbor.getX();
                    int y = neighbor.getY();
                    int currentDistance = distance[current.getX()][current.getY()];

                    if (distance[x][y] == currentDistance - 1) {            // nachbar der 1 kleiner ist
                        next = neighbor;
                    }
                }
            }
            if (next == null) {
                System.out.println(" Kein Weg gefunden.");
                return;
            }
            current = next;
            System.out.print(" -> (" + current.getX() + "|" + current.getY() + ")");
        }
        System.out.println();
    }
}