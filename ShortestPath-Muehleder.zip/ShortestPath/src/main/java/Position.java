import java.util.Objects;

public class Position {

    private int x;
    private int y;

    public Position(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public  Position[] getNeighbors(){

        Position[] neighbours = new Position[4];
        neighbours[0] = new Position(x, y + 1);
        neighbours[1] = new Position(x + 1, y);
        neighbours[2] = new Position(x, y - 1);
        neighbours[3] = new Position(x - 1, y);

        return neighbours;
    };

    public String toString() {
        return "(" + x + "|" + y + ")";
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        Position position = (Position) object;
        return x == position.x && y == position.y;
    }

    @Override
    public int hashCode() {
        return Objects.hash(x, y);
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }
}
